#ifndef VIZ_H
#define VIZ_H

int viz_run(int argc, char **argv);
int viz_hit(float range, float angle);

#endif
