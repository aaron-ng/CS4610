Ho Yat Aaron, Ng
Youtube URLs:
HW06 Maze:  https://youtu.be/5o27HTUiDm0 
HW05 Maze:  https://youtu.be/t_sqKN7OYOQ 

Additional Comments:
The overarching idea is sound, the map generation and cleanliness could have been improved but is suffucient for task. If done again I would have used the coffen-hw06 brain that maps the occupency grid even better. In the youtube videos I do move the robot once or twice during the filming to make the video simply shorter, without it the robot would take double or triple its time, simply because the mapping on the first run is inconsistent and creates patchy obstacles. Multiple runs over an obstacle simply takes too much time.

Like I said, the overarching logic is correct. Just need some refinement :D