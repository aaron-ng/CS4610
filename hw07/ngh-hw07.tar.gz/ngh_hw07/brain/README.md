
# Brain, for HW06 starter code

Dependencies:

```
$ sudo apt install libgtk-3-dev libcairo2-dev
```

Files you should edit for your solution:

 - brain.cc
 - viz.h / viz.cc

Files you should leave unchanged:

 - robot.h / robot.cc
